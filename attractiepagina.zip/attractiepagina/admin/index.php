<?php
header("Location: attracties/index.php");
?>